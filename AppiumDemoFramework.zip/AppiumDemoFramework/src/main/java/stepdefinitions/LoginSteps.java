package stepdefinitions;

import com.aventstack.extentreports.Status;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.base.BaseClass;
import pagefactory.LoginScreen;

public class LoginSteps extends BaseClass {

    private LoginScreen loginScreen;

    @Given("^The user is on the HomeScreen$")
    public void the_user_is_on_the_HomeScreen() {
        loginScreen = new LoginScreen(getdriver());
        boolean isDisplayed = loginScreen.isLoginScreenDisplayed();
        if (isDisplayed) {
            getExtentTest().log(Status.PASS, "✅ Home screen is displayed.");
        } else {
            getExtentTest().log(Status.FAIL, "❌ Home screen is not displayed.");
        }
    }

    @When("^Click the view menu option$")
    public void click_the_view_menu_option() {
        loginScreen.clickOnViewMenuOption();
        getExtentTest().log(Status.INFO, "✅ Clicked on the View menu option.");
    }

    @When("^Click the login button$")
    public void click_the_login_button() {
        loginScreen.clickOnLoginButton();
        getExtentTest().log(Status.INFO, "✅ Clicked on the Login button.");
    }

    @Then("^Verify the presence of LoginScreen$")
    public void verify_the_presence_of_LoginScreen() {
        loginScreen.verifyThePresenceOfLoginScreen();
        getExtentTest().log(Status.PASS, "✅ Login screen is displayed.");
    }
}
