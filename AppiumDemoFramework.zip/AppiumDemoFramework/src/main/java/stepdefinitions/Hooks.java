package stepdefinitions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.base.BaseClass;
import utility.ExtentReportManager;

public class Hooks extends BaseClass {

    @Before
    public void cucumberBefore(Scenario scenario) {
        // Create test entry in extent report
        ExtentTest test = ExtentReportManager.getInstance().createTest(scenario.getName());
        setExtentTest(test);
        getExtentTest().log(Status.INFO, "🔹 Scenario Started: " + scenario.getName());
    }

    @After
    public void cucumberAfter(Scenario scenario) {
        ExtentTest test = getExtentTest();

        if (scenario.isFailed()) {
            test.log(Status.FAIL, "❌ Scenario Failed: " + scenario.getName());
        } else {
            test.log(Status.PASS, "✅ Scenario Passed: " + scenario.getName());
        }

        // Flush extent report safely
        try {
            ExtentReportManager.getInstance().flush();
        } catch (Exception e) {
            System.err.println("❗ Error flushing ExtentReport: " + e.getMessage());
        }

        // Cleanup driver
        if (driver.get() != null) {
            driver.get().quit();
            driver.remove();
        }
    }
}
