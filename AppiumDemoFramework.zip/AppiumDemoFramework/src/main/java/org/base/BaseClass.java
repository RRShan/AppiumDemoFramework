package org.base;

import com.aventstack.extentreports.ExtentTest;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.ios.IOSDriver;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

public class BaseClass {
    protected static ThreadLocal<AppiumDriver> driver = new ThreadLocal<>();
    protected static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();
    public  String deviceName;
    public  String appFileName;
    public  String iosDeviceName;
    public  String iosAppFileName;
    public String platform;

    public AppiumDriver getdriver() {
        return driver.get();
    }

    public static ExtentTest getExtentTest() {
        return extentTest.get();
    }

    public static void setExtentTest(ExtentTest test) {
        extentTest.set(test);
    }

    public void androidLocalVirtualDevice() throws MalformedURLException {
        try {
            UiAutomator2Options capAndroid = new UiAutomator2Options();
            capAndroid.setCapability("automationName", "UiAutomator2");
            capAndroid.setCapability("deviceName", deviceName);
            capAndroid.setCapability("app", System.getProperty("user.dir") + "\\App\\Demo.apk");
            driver.set(new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capAndroid)); //
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void iosLocalVirtualDevice() throws MalformedURLException {
        try {
            UiAutomator2Options capAndroid = new UiAutomator2Options();
            capAndroid.setCapability("platform", "IOS");
            capAndroid.setCapability("automationName", "XCUITest");
            capAndroid.setCapability("deviceName", iosDeviceName);
            capAndroid.setCapability("app", System.getProperty("user.dir")+iosAppFileName);
            driver.set(new IOSDriver(new URL("http://127.0.0.1:4723/wd/hub"), capAndroid));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}

