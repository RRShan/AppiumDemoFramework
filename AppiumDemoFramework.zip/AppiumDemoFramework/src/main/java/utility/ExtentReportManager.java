package utility;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.base.BaseClass;

import java.io.File;
import java.net.URL;

public class ExtentReportManager extends BaseClass {
    public static synchronized ExtentReports getInstance() {
        ExtentSparkReporter spark = new ExtentSparkReporter("target/extent-report.html");

        try {
            // Get the path of the file from resources
            URL resource = ExtentReportManager.class.getClassLoader().getResource("extent-config.xml");
            if (resource == null) {
                throw new RuntimeException("extent-config.xml not found on classpath");
            }

            spark.loadXMLConfig(new File(resource.toURI()));

        } catch (Exception e) {
            throw new RuntimeException("Failed to load extent-config.xml", e);
        }

        ExtentReports extent = new ExtentReports();
        extent.attachReporter(spark);
        extent.setSystemInfo("OS", System.getProperty("os.name"));
        extent.setSystemInfo("Java", System.getProperty("java.version"));
        return extent;
    }
}
