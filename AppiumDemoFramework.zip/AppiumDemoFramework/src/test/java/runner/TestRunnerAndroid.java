package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import org.base.BaseClass;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import java.net.MalformedURLException;

@CucumberOptions(
        features = "src/main/java/features/Login.feature",
        glue = {"stepdefinitions"},
        plugin = {
                "pretty",
                "html:target/cucumber-html-report",
                "json:target/cucumber.json"
        },
        monochrome = true
)
public class TestRunnerAndroid extends AbstractTestNGCucumberTests {

    BaseClass base = new BaseClass();

    @Parameters({"platform", "deviceName", "appFileName"})
    @BeforeSuite(alwaysRun = true)
    public void beforeSuite(
            @Optional("android") String platform,
            @Optional("emulator-5554") String deviceName,
            @Optional("/App/Demo.apk") String appFileName
    ) throws MalformedURLException {

        base.platform = platform;
        base.deviceName = deviceName;
        base.appFileName = appFileName;

        System.out.println("Platform: " + platform);
        System.out.println("Device Name: " + deviceName);
        System.out.println("App File: " + appFileName);


        if (platform.equalsIgnoreCase("android")) {
            base.androidLocalVirtualDevice();
        } else {
            throw new RuntimeException("Unsupported platform: " + platform);
        }
    }

    @Override
    @DataProvider(parallel = false)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}
